import { Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

@Component({
  selector: 'app-basics-of-law',
  templateUrl: './basics-of-law.component.html',
  styleUrls: ['./basics-of-law.component.css']
})
export class BasicsOfLawComponent {

}
