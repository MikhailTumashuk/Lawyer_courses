export interface IAppConfig {
    backend: string
}